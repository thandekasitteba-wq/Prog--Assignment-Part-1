/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainregister;

/**
 *
 * @author Lenovo
 */
public class MainRegister {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
